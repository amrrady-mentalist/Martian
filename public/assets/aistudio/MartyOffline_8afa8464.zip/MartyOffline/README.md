# Marty (offline) — Kotlin / Jetpack Compose

A modern, fully offline rebuild of the Offline mode of the old Marty app. No Facebook, no server,
and **no INTERNET permission** in the manifest.

## The effect
1. **Perform** → photograph a card (or pick a photo).
2. Marty finds the card (OpenCV) while you enter the secret code on a fake system screen.
3. The card in the photo is replaced by the one you chose.
4. A fake camera roll opens on the edited photo (newest picture, with your fake-roll pictures before it).

## Entering the card (two disguises, pick one in Options)
Both produce the same 3 secret digits:

| digit | meaning |
|-------|---------|
| 1     | suit position in your suit order (default 1♣ 2♥ 3♠ 4♦) |
| 2–3   | card value `01`–`13`; with **+1** on (default) it is value + 1, so Ace = `02` … King = `14` |

Example (defaults): Queen of Hearts = `2` `13` → **213**.

* **Fake lock screen** (ported from your N.list project): black screen → double-tap → always-on clock
  → swipe up → PIN pad. Type 4 digits (or 6 with the option). Only the first 3 matter; the rest is filler.
  Double-tap the "Enter PIN" header to go back to the black screen. Back button = abandon.
* **Fake home screen** (ported from N.list): 4 pages of decoy apps. Each swipe to the next page records one
  digit, decided by where your thumb *starts*: the bottom-right 3×3 block of the 4×6 grid is an invisible
  keypad (1–9), anywhere else is 0. After 3 swipes, tap the **Photos** icon on the last page. The status-bar
  clock peeks at the digits entered so far (like `02:13`). Double-tap the dock's lock icon to abandon.

## Project layout
```
data/    Settings (prefs), CardCode (digits <-> card)
vision/  CardDetector (OpenCV contours), CardCompositor (warp + light match + blend),
         CardFaceRenderer (draws all 52 faces in code, no artwork), Quad
ui/      LockInputFlow, HomeScreenInput (ported from N.list), CaptureScreen (CameraX),
         QuadScreen (training view + manual corner fix), GalleryRevealScreen, OptionsScreen, MenuScreen
```

## Build
Open the folder in Android Studio (Ladybug or newer) and run. CLI / CI: `gradle assembleDebug`
(see `.github/workflows/build-apk.yml`). Requires JDK 17. minSdk 29, targetSdk 34.

## Things to tune on a real phone
* `CardDetector`: Canny thresholds (40/120) and the aspect-ratio window (0.50–0.88).
* `CardCompositor`: the 1.035 quad enlargement (hides the old card's edge), the 0.8 blur, the brightness gain.
* `CardFaceRenderer`: card faces are simple and drawn in code. Swap in your own artwork if you like.
* Training mode shows what the detector sees, so use it to learn good framing.

## Known limits
* A hand or finger covering part of the card gets painted over by the new face.
* If detection fails, the corner editor opens so you can drag the four corners (you'll want to avoid this on stage).
* The code was written without a build environment here, so expect to fix a small compile error or two on first sync.
